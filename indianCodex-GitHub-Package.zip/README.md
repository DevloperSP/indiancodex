# IndianCodex - Phishing Tool

## Installation

### For Termux:
```bash
pkg update && pkg upgrade
pkg install git python unzip
git clone https://github.com/DeveloperSP/indiancodex.git
cd indiancodex
unzip indiancodex-phisher.zip
cd indiancodex-phisher
python phisher.py
```

### For Kali Linux:
```bash
sudo apt update && sudo apt upgrade
sudo apt install git python3 unzip
git clone https://github.com/DeveloperSP/indiancodex.git
cd indiancodex
unzip indiancodex-phisher.zip
cd indiancodex-phisher
python3 phisher.py
```

![Preview](assets/preview.gif)

---
Made with 💜 by DeveloperSP
